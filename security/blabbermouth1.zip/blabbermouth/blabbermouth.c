/* Tutorial support files.  
 * see recluze.wordpress.com for details 
 *  
 */ 


#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/tracehook.h>
#include <linux/errno.h>
#include <linux/sched.h>
#include <linux/security.h>
#include <linux/xattr.h>
#include <linux/capability.h>
#include <linux/unistd.h>
#include <linux/mm.h>
#include <linux/mman.h>
#include <linux/slab.h>
#include <linux/pagemap.h>
#include <linux/swap.h>
#include <linux/spinlock.h>
#include <linux/syscalls.h>
#include <linux/file.h>
#include <linux/fdtable.h>
#include <linux/namei.h>
#include <linux/mount.h>
#include <linux/proc_fs.h>
#include <linux/netfilter_ipv4.h>
#include <linux/netfilter_ipv6.h>
#include <linux/tty.h>
#include <net/icmp.h>
#include <net/ip.h>		/* for local_port_range[] */
#include <net/tcp.h>		/* struct or_callable used in sock_rcv_skb */
#include <net/net_namespace.h>
#include <net/netlabel.h>
#include <linux/uaccess.h>
#include <asm/ioctls.h>
#include <asm/atomic.h>
#include <linux/bitops.h>
#include <linux/interrupt.h>
#include <linux/netdevice.h>	/* for network interface checks */
#include <linux/netlink.h>
#include <linux/tcp.h>
#include <linux/udp.h>
#include <linux/dccp.h>
#include <linux/quota.h>
#include <linux/un.h>		/* for Unix socket types */
#include <net/af_unix.h>	/* for Unix socket types */
#include <linux/parser.h>
#include <linux/nfs_mount.h>
#include <net/ipv6.h>
#include <linux/hugetlb.h>
#include <linux/personality.h>
#include <linux/sysctl.h>
#include <linux/audit.h>
#include <linux/string.h>
#include <linux/mutex.h>
#include <linux/posix-timers.h>



#ifdef CONFIG_SECURITY_BLABBERMOUTH 



static int blabbermouth_acct(struct file *file)
{
	return 0;
}

static int blabbermouth_sysctl(ctl_table *table, int op)
{
	return 0;
}

static int blabbermouth_quotactl(int cmds, int type, int id, struct super_block *sb)
{
	return 0;
}

static int blabbermouth_quota_on(struct dentry *dentry)
{
	return 0;
}

static int blabbermouth_bprm_check_security (struct linux_binprm *bprm)
{
	return 0;
}

static void blabbermouth_bprm_committing_creds(struct linux_binprm *bprm)
{
}

static void blabbermouth_bprm_committed_creds(struct linux_binprm *bprm)
{
}

static int blabbermouth_sb_alloc_security(struct super_block *sb)
{
	return 0;
}

static void blabbermouth_sb_free_security(struct super_block *sb)
{
}

static int blabbermouth_sb_copy_data(char *orig, char *copy)
{
	return 0;
}

static int blabbermouth_sb_kern_mount(struct super_block *sb, int flags, void *data)
{
	return 0;
}

static int blabbermouth_sb_show_options(struct seq_file *m, struct super_block *sb)
{
	return 0;
}

static int blabbermouth_sb_statfs(struct dentry *dentry)
{
	return 0;
}

static int blabbermouth_sb_mount(char *dev_name, struct path *path, char *type,
			unsigned long flags, void *data)
{
	return 0;
}

static int blabbermouth_sb_check_sb(struct vfsmount *mnt, struct path *path)
{
	return 0;
}

static int blabbermouth_sb_umount(struct vfsmount *mnt, int flags)
{
	return 0;
}

static void blabbermouth_sb_umount_close(struct vfsmount *mnt)
{
}

static void blabbermouth_sb_umount_busy(struct vfsmount *mnt)
{
}

static void blabbermouth_sb_post_remount(struct vfsmount *mnt, unsigned long flags,
				void *data)
{
}

static void blabbermouth_sb_post_addmount(struct vfsmount *mnt, struct path *path)
{
}

static int blabbermouth_sb_pivotroot(struct path *old_path, struct path *new_path)
{
	return 0;
}

static void blabbermouth_sb_post_pivotroot(struct path *old_path, struct path *new_path)
{
}

static int blabbermouth_sb_set_mnt_opts(struct super_block *sb,
			       struct security_mnt_opts *opts)
{
	if (unlikely(opts->num_mnt_opts))
		return -EOPNOTSUPP;
	return 0;
}

static void blabbermouth_sb_clone_mnt_opts(const struct super_block *oldsb,
				  struct super_block *newsb)
{
}

static int blabbermouth_sb_parse_opts_str(char *options, struct security_mnt_opts *opts)
{
	return 0;
}

static int blabbermouth_inode_alloc_security(struct inode *inode)
{
	return 0;
}

static void blabbermouth_inode_free_security(struct inode *inode)
{
}

static int blabbermouth_inode_init_security(struct inode *inode, struct inode *dir,
				   char **name, void **value, size_t *len)
{
	return -EOPNOTSUPP;
}

static int blabbermouth_inode_create(struct inode *inode, struct dentry *dentry,
			    int mask)
{
	return 0;
}

static int blabbermouth_inode_link(struct dentry *old_dentry, struct inode *inode,
			  struct dentry *new_dentry)
{
	return 0;
}

static int blabbermouth_inode_unlink(struct inode *inode, struct dentry *dentry)
{
	return 0;
}

static int blabbermouth_inode_symlink(struct inode *inode, struct dentry *dentry,
			     const char *name)
{
	return 0;
}

static int blabbermouth_inode_mkdir(struct inode *inode, struct dentry *dentry,
			   int mask)
{
	return 0;
}

static int blabbermouth_inode_rmdir(struct inode *inode, struct dentry *dentry)
{
	return 0;
}

static int blabbermouth_inode_mknod(struct inode *inode, struct dentry *dentry,
			   int mode, dev_t dev)
{
	return 0;
}

static int blabbermouth_inode_rename(struct inode *old_inode, struct dentry *old_dentry,
			    struct inode *new_inode, struct dentry *new_dentry)
{
	return 0;
}

static int blabbermouth_inode_readlink(struct dentry *dentry)
{
	return 0;
}

static int blabbermouth_inode_follow_link(struct dentry *dentry,
				 struct nameidata *nameidata)
{
	return 0;
}

static int blabbermouth_inode_permission(struct inode *inode, int mask)
{
	return 0;
}

static int blabbermouth_inode_setattr(struct dentry *dentry, struct iattr *iattr)
{
	return 0;
}

static int blabbermouth_inode_getattr(struct vfsmount *mnt, struct dentry *dentry)
{
	return 0;
}

static void blabbermouth_inode_delete(struct inode *ino)
{
}

static void blabbermouth_inode_post_setxattr(struct dentry *dentry, const char *name,
				    const void *value, size_t size, int flags)
{
}

static int blabbermouth_inode_getxattr(struct dentry *dentry, const char *name)
{
	return 0;
}

static int blabbermouth_inode_listxattr(struct dentry *dentry)
{
	return 0;
}

static int blabbermouth_inode_getsecurity(const struct inode *inode, const char *name,
				 void **buffer, bool alloc)
{
	return -EOPNOTSUPP;
}

static int blabbermouth_inode_setsecurity(struct inode *inode, const char *name,
				 const void *value, size_t size, int flags)
{
	return -EOPNOTSUPP;
}

static int blabbermouth_inode_listsecurity(struct inode *inode, char *buffer,
				  size_t buffer_size)
{
	return 0;
}

static void blabbermouth_inode_getsecid(const struct inode *inode, u32 *secid)
{
	*secid = 0;
}

#ifdef CONFIG_SECURITY_PATH
static int blabbermouth_path_mknod(struct path *dir, struct dentry *dentry, int mode,
			  unsigned int dev)
{
	return 0;
}

static int blabbermouth_path_mkdir(struct path *dir, struct dentry *dentry, int mode)
{
	return 0;
}

static int blabbermouth_path_rmdir(struct path *dir, struct dentry *dentry)
{
	return 0;
}

static int blabbermouth_path_unlink(struct path *dir, struct dentry *dentry)
{
	return 0;
}

static int blabbermouth_path_symlink(struct path *dir, struct dentry *dentry,
			    const char *old_name)
{
	return 0;
}

static int blabbermouth_path_link(struct dentry *old_dentry, struct path *new_dir,
			 struct dentry *new_dentry)
{
	return 0;
}

static int blabbermouth_path_rename(struct path *old_path, struct dentry *old_dentry,
			   struct path *new_path, struct dentry *new_dentry)
{
	return 0;
}

static int blabbermouth_path_truncate(struct path *path, loff_t length,
			     unsigned int time_attrs)
{
	return 0;
}

static int blabbermouth_path_chmod(struct dentry *dentry, struct vfsmount *mnt,
			  mode_t mode)
{
	return 0;
}

static int blabbermouth_path_chown(struct path *path, uid_t uid, gid_t gid)
{
	return 0;
}

static int blabbermouth_path_chroot(struct path *root)
{
	return 0;
}
#endif

static int blabbermouth_file_permission(struct file *file, int mask)
{
	printk("blabbermouth: file_permission called\n");
	return 0;
}

static int blabbermouth_file_alloc_security(struct file *file)
{
	return 0;
}

static void blabbermouth_file_free_security(struct file *file)
{
}

static int blabbermouth_file_ioctl(struct file *file, unsigned int command,
			  unsigned long arg)
{
	return 0;
}

static int blabbermouth_file_mprotect(struct vm_area_struct *vma, unsigned long reqprot,
			     unsigned long prot)
{
	return 0;
}

static int blabbermouth_file_lock(struct file *file, unsigned int cmd)
{
	return 0;
}

static int blabbermouth_file_fcntl(struct file *file, unsigned int cmd,
			  unsigned long arg)
{
	return 0;
}

static int blabbermouth_file_set_fowner(struct file *file)
{
	return 0;
}

static int blabbermouth_file_send_sigiotask(struct task_struct *tsk,
				   struct fown_struct *fown, int sig)
{
	return 0;
}

static int blabbermouth_file_receive(struct file *file)
{
	return 0;
}

static int blabbermouth_dentry_open(struct file *file, const struct cred *cred)
{
	return 0;
}

static int blabbermouth_task_create(unsigned long clone_flags)
{
	return 0;
}

static int blabbermouth_cred_alloc_blank(struct cred *cred, gfp_t gfp)
{
	return 0;
}

static void blabbermouth_cred_free(struct cred *cred)
{
}

static int blabbermouth_cred_prepare(struct cred *new, const struct cred *old, gfp_t gfp)
{
	return 0;
}

static void blabbermouth_cred_commit(struct cred *new, const struct cred *old)
{
}

static void blabbermouth_cred_transfer(struct cred *new, const struct cred *old)
{
}

static int blabbermouth_kernel_act_as(struct cred *new, u32 secid)
{
	return 0;
}

static int blabbermouth_kernel_create_files_as(struct cred *new, struct inode *inode)
{
	return 0;
}

static int blabbermouth_kernel_module_request(char *kmod_name)
{
	return 0;
}

static int blabbermouth_task_setuid(uid_t id0, uid_t id1, uid_t id2, int flags)
{
	return 0;
}

static int blabbermouth_task_setgid(gid_t id0, gid_t id1, gid_t id2, int flags)
{
	return 0;
}

static int blabbermouth_task_setpgid(struct task_struct *p, pid_t pgid)
{
	return 0;
}

static int blabbermouth_task_getpgid(struct task_struct *p)
{
	return 0;
}

static int blabbermouth_task_getsid(struct task_struct *p)
{
	return 0;
}

static void blabbermouth_task_getsecid(struct task_struct *p, u32 *secid)
{
	*secid = 0;
}

static int blabbermouth_task_setgroups(struct group_info *group_info)
{
	return 0;
}

static int blabbermouth_task_getioprio(struct task_struct *p)
{
	return 0;
}

static int blabbermouth_task_setrlimit(unsigned int resource, struct rlimit *new_rlim)
{
	return 0;
}

static int blabbermouth_task_getscheduler(struct task_struct *p)
{
	return 0;
}

static int blabbermouth_task_movememory(struct task_struct *p)
{
	return 0;
}

static int blabbermouth_task_wait(struct task_struct *p)
{
	return 0;
}

static int blabbermouth_task_kill(struct task_struct *p, struct siginfo *info,
			 int sig, u32 secid)
{
	return 0;
}

static void blabbermouth_task_to_inode(struct task_struct *p, struct inode *inode)
{
}

static int blabbermouth_ipc_permission(struct kern_ipc_perm *ipcp, short flag)
{
	return 0;
}

static void blabbermouth_ipc_getsecid(struct kern_ipc_perm *ipcp, u32 *secid)
{
	*secid = 0;
}

static int blabbermouth_msg_msg_alloc_security(struct msg_msg *msg)
{
	return 0;
}

static void blabbermouth_msg_msg_free_security(struct msg_msg *msg)
{
}

static int blabbermouth_msg_queue_alloc_security(struct msg_queue *msq)
{
	return 0;
}

static void blabbermouth_msg_queue_free_security(struct msg_queue *msq)
{
}

static int blabbermouth_msg_queue_associate(struct msg_queue *msq, int msqflg)
{
	return 0;
}

static int blabbermouth_msg_queue_msgctl(struct msg_queue *msq, int cmd)
{
	return 0;
}

static int blabbermouth_msg_queue_msgsnd(struct msg_queue *msq, struct msg_msg *msg,
				int msgflg)
{
	return 0;
}

static int blabbermouth_msg_queue_msgrcv(struct msg_queue *msq, struct msg_msg *msg,
				struct task_struct *target, long type, int mode)
{
	return 0;
}

static int blabbermouth_shm_alloc_security(struct shmid_kernel *shp)
{
	return 0;
}

static void blabbermouth_shm_free_security(struct shmid_kernel *shp)
{
}

static int blabbermouth_shm_associate(struct shmid_kernel *shp, int shmflg)
{
	return 0;
}

static int blabbermouth_shm_shmctl(struct shmid_kernel *shp, int cmd)
{
	return 0;
}

static int blabbermouth_shm_shmat(struct shmid_kernel *shp, char __user *shmaddr,
			 int shmflg)
{
	return 0;
}

static int blabbermouth_sem_alloc_security(struct sem_array *sma)
{
	return 0;
}

static void blabbermouth_sem_free_security(struct sem_array *sma)
{
}

static int blabbermouth_sem_associate(struct sem_array *sma, int semflg)
{
	return 0;
}

static int blabbermouth_sem_semctl(struct sem_array *sma, int cmd)
{
	return 0;
}

static int blabbermouth_sem_semop(struct sem_array *sma, struct sembuf *sops,
			 unsigned nsops, int alter)
{
	return 0;
}

#ifdef CONFIG_SECURITY_NETWORK
static int blabbermouth_unix_stream_connect(struct socket *sock, struct socket *other,
				   struct sock *newsk)
{
	printk("blabbermouth: unix_stream_connect called\n");
	return 0;
}

static int blabbermouth_unix_may_send(struct socket *sock, struct socket *other)
{
	return 0;
}

static int blabbermouth_socket_create(int family, int type, int protocol, int kern)
{
	printk("blabbermouth: socket_create called\n"); 
	return 0;
}

static int blabbermouth_socket_post_create(struct socket *sock, int family, int type,
				  int protocol, int kern)
{
	return 0;
}

static int blabbermouth_socket_bind(struct socket *sock, struct sockaddr *address,
			   int addrlen)
{
	return 0;
}

static int blabbermouth_socket_connect(struct socket *sock, struct sockaddr *address,
			      int addrlen)
{
	printk("blabbermouth: socket_connect called\n");
	return 0;
}

static int blabbermouth_socket_listen(struct socket *sock, int backlog)
{
	return 0;
}

static int blabbermouth_socket_accept(struct socket *sock, struct socket *newsock)
{
	return 0;
}

static int blabbermouth_socket_sendmsg(struct socket *sock, struct msghdr *msg, int size)
{
	return 0;
}

static int blabbermouth_socket_recvmsg(struct socket *sock, struct msghdr *msg,
			      int size, int flags)
{
	return 0;
}

static int blabbermouth_socket_getsockname(struct socket *sock)
{
	return 0;
}

static int blabbermouth_socket_getpeername(struct socket *sock)
{
	return 0;
}

static int blabbermouth_socket_setsockopt(struct socket *sock, int level, int optname)
{
	return 0;
}

static int blabbermouth_socket_getsockopt(struct socket *sock, int level, int optname)
{
	return 0;
}

static int blabbermouth_socket_shutdown(struct socket *sock, int how)
{
	return 0;
}

static int blabbermouth_socket_sock_rcv_skb(struct sock *sk, struct sk_buff *skb)
{
	return 0;
}

static int blabbermouth_socket_getpeersec_stream(struct socket *sock,
					char __user *optval,
					int __user *optlen, unsigned len)
{
	return 0;
}

static int blabbermouth_socket_getpeersec_dgram(struct socket *sock,
				       struct sk_buff *skb, u32 *secid)
{
	return 0;
}

static int blabbermouth_sk_alloc_security(struct sock *sk, int family, gfp_t priority)
{
	return 0;
}

static void blabbermouth_sk_free_security(struct sock *sk)
{
}

static void blabbermouth_sk_clone_security(const struct sock *sk, struct sock *newsk)
{
}

static void blabbermouth_sk_getsecid(struct sock *sk, u32 *secid)
{
}

static void blabbermouth_sock_graft(struct sock *sk, struct socket *parent)
{
}

static int blabbermouth_inet_conn_request(struct sock *sk, struct sk_buff *skb,
				 struct request_sock *req)
{
	return 0;
}

static void blabbermouth_inet_csk_clone(struct sock *newsk,
			       const struct request_sock *req)
{
}

static void blabbermouth_inet_conn_established(struct sock *sk, struct sk_buff *skb)
{
}



static void blabbermouth_req_classify_flow(const struct request_sock *req,
				  struct flowi *fl)
{
}

static int blabbermouth_tun_dev_create(void)
{
	return 0;
}

static void blabbermouth_tun_dev_post_create(struct sock *sk)
{
}

static int blabbermouth_tun_dev_attach(struct sock *sk)
{
	return 0;
}
#endif	/* CONFIG_SECURITY_NETWORK */

#ifdef CONFIG_SECURITY_NETWORK_XFRM
static int blabbermouth_xfrm_policy_alloc_security(struct xfrm_sec_ctx **ctxp,
					  struct xfrm_user_sec_ctx *sec_ctx)
{
	return 0;
}

static int blabbermouth_xfrm_policy_clone_security(struct xfrm_sec_ctx *old_ctx,
					  struct xfrm_sec_ctx **new_ctxp)
{
	return 0;
}

static void blabbermouth_xfrm_policy_free_security(struct xfrm_sec_ctx *ctx)
{
}

static int blabbermouth_xfrm_policy_delete_security(struct xfrm_sec_ctx *ctx)
{
	return 0;
}

static int blabbermouth_xfrm_state_alloc_security(struct xfrm_state *x,
					 struct xfrm_user_sec_ctx *sec_ctx,
					 u32 secid)
{
	return 0;
}

static void blabbermouth_xfrm_state_free_security(struct xfrm_state *x)
{
}

static int blabbermouth_xfrm_state_delete_security(struct xfrm_state *x)
{
	return 0;
}

static int blabbermouth_xfrm_policy_lookup(struct xfrm_sec_ctx *ctx, u32 sk_sid, u8 dir)
{
	return 0;
}

static int blabbermouth_xfrm_state_pol_flow_match(struct xfrm_state *x,
					 struct xfrm_policy *xp,
					 struct flowi *fl)
{
	return 1;
}

static int blabbermouth_xfrm_decode_session(struct sk_buff *skb, u32 *fl, int ckall)
{
	return 0;
}

#endif /* CONFIG_SECURITY_NETWORK_XFRM */
static void blabbermouth_d_instantiate(struct dentry *dentry, struct inode *inode)
{
}

static int blabbermouth_getprocattr(struct task_struct *p, char *name, char **value)
{
	return -EINVAL;
}

static int blabbermouth_setprocattr(struct task_struct *p, char *name, void *value,
			   size_t size)
{
	return -EINVAL;
}

static int blabbermouth_secid_to_secctx(u32 secid, char **secdata, u32 *seclen)
{
	return -EOPNOTSUPP;
}

static int blabbermouth_secctx_to_secid(const char *secdata, u32 seclen, u32 *secid)
{
	return -EOPNOTSUPP;
}

static void blabbermouth_release_secctx(char *secdata, u32 seclen)
{
}

static int blabbermouth_inode_notifysecctx(struct inode *inode, void *ctx, u32 ctxlen)
{
	return 0;
}

static int blabbermouth_inode_setsecctx(struct dentry *dentry, void *ctx, u32 ctxlen)
{
	return 0;
}

static int blabbermouth_inode_getsecctx(struct inode *inode, void **ctx, u32 *ctxlen)
{
	return 0;
}
#ifdef CONFIG_KEYS
static int blabbermouth_key_alloc(struct key *key, const struct cred *cred,
			 unsigned long flags)
{
	return 0;
}

static void blabbermouth_key_free(struct key *key)
{
}

static int blabbermouth_key_permission(key_ref_t key_ref, const struct cred *cred,
			      key_perm_t perm)
{
	return 0;
}

static int blabbermouth_key_getsecurity(struct key *key, char **_buffer)
{
	*_buffer = NULL;
	return 0;
}

static int blabbermouth_key_session_to_parent(const struct cred *cred,
				     const struct cred *parent_cred,
				     struct key *key)
{
	return 0;
}

#endif /* CONFIG_KEYS */

#ifdef CONFIG_AUDIT
static int blabbermouth_audit_rule_init(u32 field, u32 op, char *rulestr, void **lsmrule)
{
	return 0;
}

static int blabbermouth_audit_rule_known(struct audit_krule *krule)
{
	return 0;
}

static int blabbermouth_audit_rule_match(u32 secid, u32 field, u32 op, void *lsmrule,
				struct audit_context *actx)
{
	return 0;
}

static void blabbermouth_audit_rule_free(void *lsmrule)
{
}
#endif /* CONFIG_AUDIT */


static int blabbermouth_ptrace_access_check(struct task_struct *child,
				     unsigned int mode)
{
	return 0;
}

static int blabbermouth_ptrace_traceme(struct task_struct *parent)
{
	return 0;
}

static int blabbermouth_capget(struct task_struct *target, kernel_cap_t *effective,
			  kernel_cap_t *inheritable, kernel_cap_t *permitted)
{
	return 0;
}

static int blabbermouth_capset(struct cred *new, const struct cred *old,
			  const kernel_cap_t *effective,
			  const kernel_cap_t *inheritable,
			  const kernel_cap_t *permitted)
{
	return 0;	
}


static int blabbermouth_capable(struct task_struct *tsk, const struct cred *cred,
			   int cap, int audit)
{
	return 0;
}

static int blabbermouth_syslog(int type)
{
	return 0;
}

static int blabbermouth_vm_enough_memory(struct mm_struct *mm, long pages)
{
	return 0;
}

static int blabbermouth_netlink_send(struct sock *sk, struct sk_buff *skb)
{
	return 0;
}

static int blabbermouth_netlink_recv(struct sk_buff *skb, int capability)
{
	return 0;	
}

static int blabbermouth_bprm_set_creds(struct linux_binprm *bprm)
{
	return 0;
}

static int blabbermouth_bprm_secureexec(struct linux_binprm *bprm)
{
	return 0;
}
	
static int blabbermouth_mount(char *dev_name,
			 struct path *path,
			 char *type,
			 unsigned long flags,
			 void *data)
{
	return 0;
} 

static int blabbermouth_umount(struct vfsmount *mnt, int flags)
{
	return 0;
} 


static int blabbermouth_set_mnt_opts(struct super_block *sb,
				struct security_mnt_opts *opts)
{
	return 0;
} 




static int blabbermouth_parse_opts_str(char *options,
				  struct security_mnt_opts *opts)
{
	return 0;
} 




static int blabbermouth_inode_setxattr(struct dentry *dentry, const char *name,
				  const void *value, size_t size, int flags)
{
	return 0;
} 


static int blabbermouth_inode_removexattr(struct dentry *dentry, const char *name)
{
	return 0;
} 





static int blabbermouth_file_mmap(struct file *file, unsigned long reqprot,
			     unsigned long prot, unsigned long flags,
			     unsigned long addr, unsigned long addr_only)
{
	printk("blabbermouth: file_mmap called\n");
	return 0;
} 






static int blabbermouth_task_setnice(struct task_struct *p, int nice)
{
	return 0;
} 





static int blabbermouth_task_setioprio(struct task_struct *p, int ioprio)
{
	return 0;
} 



static int blabbermouth_task_setscheduler(struct task_struct *p, int policy, struct sched_param *lp)
{
	return 0;
} 


static int blabbermouth_socket_unix_stream_connect(struct socket *sock,
					      struct socket *other,
					      struct sock *newsk)
{
	return 0;
} 


static int blabbermouth_socket_unix_may_send(struct socket *sock,
					struct socket *other)
{
	return 0;
} 




static struct security_operations blabbermouth_ops = {
	.name =				"blabbermouth",
	/*
	.ptrace_access_check =		blabbermouth_ptrace_access_check,
	.ptrace_traceme =		blabbermouth_ptrace_traceme,
	.capget =			blabbermouth_capget,
	.capset =			blabbermouth_capset,
	.sysctl =			blabbermouth_sysctl,
	.capable =			blabbermouth_capable,
	.quotactl =			blabbermouth_quotactl,
	.quota_on =			blabbermouth_quota_on,
	.syslog =			blabbermouth_syslog,
	.vm_enough_memory =		blabbermouth_vm_enough_memory,

	.netlink_send =			blabbermouth_netlink_send,
	.netlink_recv =			blabbermouth_netlink_recv,

	.bprm_set_creds =		blabbermouth_bprm_set_creds,
	.bprm_committing_creds =	blabbermouth_bprm_committing_creds,
	.bprm_committed_creds =		blabbermouth_bprm_committed_creds,
	.bprm_secureexec =		blabbermouth_bprm_secureexec,

	.sb_alloc_security =		blabbermouth_sb_alloc_security,
	.sb_free_security =		blabbermouth_sb_free_security,
	.sb_copy_data =			blabbermouth_sb_copy_data,
	.sb_kern_mount =		blabbermouth_sb_kern_mount,
	.sb_show_options =		blabbermouth_sb_show_options,
	.sb_statfs =			blabbermouth_sb_statfs,
	.sb_mount =			blabbermouth_mount,
	.sb_umount =			blabbermouth_umount,
	.sb_set_mnt_opts =		blabbermouth_set_mnt_opts,
	.sb_clone_mnt_opts =		blabbermouth_sb_clone_mnt_opts,
	.sb_parse_opts_str = 		blabbermouth_parse_opts_str,
	*/

	.inode_alloc_security =		blabbermouth_inode_alloc_security,
	.inode_free_security =		blabbermouth_inode_free_security,
	.inode_init_security =		blabbermouth_inode_init_security,
	.inode_create =			blabbermouth_inode_create,
	.inode_link =			blabbermouth_inode_link,
	.inode_unlink =			blabbermouth_inode_unlink,
	.inode_symlink =		blabbermouth_inode_symlink,
	.inode_mkdir =			blabbermouth_inode_mkdir,
	.inode_rmdir =			blabbermouth_inode_rmdir,
	.inode_mknod =			blabbermouth_inode_mknod,
	.inode_rename =			blabbermouth_inode_rename,
	.inode_readlink =		blabbermouth_inode_readlink,
	.inode_follow_link =		blabbermouth_inode_follow_link,
	.inode_permission =		blabbermouth_inode_permission,
	.inode_setattr =		blabbermouth_inode_setattr,
	.inode_getattr =		blabbermouth_inode_getattr,
	.inode_setxattr =		blabbermouth_inode_setxattr,
	.inode_post_setxattr =		blabbermouth_inode_post_setxattr,
	.inode_getxattr =		blabbermouth_inode_getxattr,
	.inode_listxattr =		blabbermouth_inode_listxattr,
	.inode_removexattr =		blabbermouth_inode_removexattr,
	.inode_getsecurity =		blabbermouth_inode_getsecurity,
	.inode_setsecurity =		blabbermouth_inode_setsecurity,
	.inode_listsecurity =		blabbermouth_inode_listsecurity,
	.inode_getsecid =		blabbermouth_inode_getsecid,

	.file_permission =		blabbermouth_file_permission,
	.file_alloc_security =		blabbermouth_file_alloc_security,
	.file_free_security =		blabbermouth_file_free_security,
	.file_ioctl =			blabbermouth_file_ioctl,
	/*
	.file_mmap =			blabbermouth_file_mmap,
	*/
	.file_mprotect =		blabbermouth_file_mprotect,
	.file_lock =			blabbermouth_file_lock,
	.file_fcntl =			blabbermouth_file_fcntl,
	.file_set_fowner =		blabbermouth_file_set_fowner,
	.file_send_sigiotask =		blabbermouth_file_send_sigiotask,
	.file_receive =			blabbermouth_file_receive,
	/*
	.dentry_open =			blabbermouth_dentry_open,

	.task_create =			blabbermouth_task_create,
	.cred_alloc_blank =		blabbermouth_cred_alloc_blank,
	.cred_free =			blabbermouth_cred_free,
	.cred_prepare =			blabbermouth_cred_prepare,
	.cred_transfer =		blabbermouth_cred_transfer,
	.kernel_act_as =		blabbermouth_kernel_act_as,
	.kernel_create_files_as =	blabbermouth_kernel_create_files_as,
	.kernel_module_request =	blabbermouth_kernel_module_request,
	.task_setpgid =			blabbermouth_task_setpgid,
	.task_getpgid =			blabbermouth_task_getpgid,
	.task_getsid =			blabbermouth_task_getsid,
	.task_getsecid =		blabbermouth_task_getsecid,
	.task_setnice =			blabbermouth_task_setnice,
	.task_setioprio =		blabbermouth_task_setioprio,
	.task_getioprio =		blabbermouth_task_getioprio,
	.task_setrlimit =		blabbermouth_task_setrlimit,
	.task_setscheduler =		blabbermouth_task_setscheduler,
	.task_getscheduler =		blabbermouth_task_getscheduler,
	.task_movememory =		blabbermouth_task_movememory,
	.task_kill =			blabbermouth_task_kill,
	.task_wait =			blabbermouth_task_wait,
	.task_to_inode =		blabbermouth_task_to_inode,

	.ipc_permission =		blabbermouth_ipc_permission,
	.ipc_getsecid =			blabbermouth_ipc_getsecid,

	.msg_msg_alloc_security =	blabbermouth_msg_msg_alloc_security,
	.msg_msg_free_security =	blabbermouth_msg_msg_free_security,

	.msg_queue_alloc_security =	blabbermouth_msg_queue_alloc_security,
	.msg_queue_free_security =	blabbermouth_msg_queue_free_security,
	.msg_queue_associate =		blabbermouth_msg_queue_associate,
	.msg_queue_msgctl =		blabbermouth_msg_queue_msgctl,
	.msg_queue_msgsnd =		blabbermouth_msg_queue_msgsnd,
	.msg_queue_msgrcv =		blabbermouth_msg_queue_msgrcv,

	.shm_alloc_security =		blabbermouth_shm_alloc_security,
	.shm_free_security =		blabbermouth_shm_free_security,
	.shm_associate =		blabbermouth_shm_associate,
	.shm_shmctl =			blabbermouth_shm_shmctl,
	.shm_shmat =			blabbermouth_shm_shmat,

	.sem_alloc_security =		blabbermouth_sem_alloc_security,
	.sem_free_security =		blabbermouth_sem_free_security,
	.sem_associate =		blabbermouth_sem_associate,
	.sem_semctl =			blabbermouth_sem_semctl,
	.sem_semop =			blabbermouth_sem_semop,

	.d_instantiate =		blabbermouth_d_instantiate,

	.getprocattr =			blabbermouth_getprocattr,
	.setprocattr =			blabbermouth_setprocattr,

	.secid_to_secctx =		blabbermouth_secid_to_secctx,
	.secctx_to_secid =		blabbermouth_secctx_to_secid,
	.release_secctx =		blabbermouth_release_secctx,
	.inode_notifysecctx =		blabbermouth_inode_notifysecctx,
	.inode_setsecctx =		blabbermouth_inode_setsecctx,
	.inode_getsecctx =		blabbermouth_inode_getsecctx,

	.unix_stream_connect =		blabbermouth_socket_unix_stream_connect,
	.unix_may_send =		blabbermouth_socket_unix_may_send,

	.socket_create =		blabbermouth_socket_create,
	.socket_post_create =		blabbermouth_socket_post_create,
	.socket_bind =			blabbermouth_socket_bind,
	.socket_connect =		blabbermouth_socket_connect,
	.socket_listen =		blabbermouth_socket_listen,
	.socket_accept =		blabbermouth_socket_accept,
	.socket_sendmsg =		blabbermouth_socket_sendmsg,
	.socket_recvmsg =		blabbermouth_socket_recvmsg,
	.socket_getsockname =		blabbermouth_socket_getsockname,
	.socket_getpeername =		blabbermouth_socket_getpeername,
	.socket_getsockopt =		blabbermouth_socket_getsockopt,
	.socket_setsockopt =		blabbermouth_socket_setsockopt,
	.socket_shutdown =		blabbermouth_socket_shutdown,
	.socket_sock_rcv_skb =		blabbermouth_socket_sock_rcv_skb,
	.socket_getpeersec_stream =	blabbermouth_socket_getpeersec_stream,
	.socket_getpeersec_dgram =	blabbermouth_socket_getpeersec_dgram,
	.sk_alloc_security =		blabbermouth_sk_alloc_security,
	.sk_free_security =		blabbermouth_sk_free_security,
	.sk_clone_security =		blabbermouth_sk_clone_security,
	.sk_getsecid =			blabbermouth_sk_getsecid,
	.sock_graft =			blabbermouth_sock_graft,
	.inet_conn_request =		blabbermouth_inet_conn_request,
	.inet_csk_clone =		blabbermouth_inet_csk_clone,
	.inet_conn_established =	blabbermouth_inet_conn_established,
	.req_classify_flow =		blabbermouth_req_classify_flow,
	.tun_dev_create =		blabbermouth_tun_dev_create,
	.tun_dev_post_create = 		blabbermouth_tun_dev_post_create,
	.tun_dev_attach =		blabbermouth_tun_dev_attach,
	*/
#ifdef CONFIG_SECURITY_NETWORK_XFRM
	.xfrm_policy_alloc_security =	blabbermouth_xfrm_policy_alloc,
	.xfrm_policy_clone_security =	blabbermouth_xfrm_policy_clone,
	.xfrm_policy_free_security =	blabbermouth_xfrm_policy_free,
	.xfrm_policy_delete_security =	blabbermouth_xfrm_policy_delete,
	.xfrm_state_alloc_security =	blabbermouth_xfrm_state_alloc,
	.xfrm_state_free_security =	blabbermouth_xfrm_state_free,
	.xfrm_state_delete_security =	blabbermouth_xfrm_state_delete,
	.xfrm_policy_lookup =		blabbermouth_xfrm_policy_lookup,
	.xfrm_state_pol_flow_match =	blabbermouth_xfrm_state_pol_flow_match,
	.xfrm_decode_session =		blabbermouth_xfrm_decode_session,
#endif

#ifdef CONFIG_KEYS
	.key_alloc =			blabbermouth_key_alloc,
	.key_free =			blabbermouth_key_free,
	.key_permission =		blabbermouth_key_permission,
	.key_getsecurity =		blabbermouth_key_getsecurity,
#endif

#ifdef CONFIG_AUDIT
	.audit_rule_init =		blabbermouth_audit_rule_init,
	.audit_rule_known =		blabbermouth_audit_rule_known,
	.audit_rule_match =		blabbermouth_audit_rule_match,
	.audit_rule_free =		blabbermouth_audit_rule_free,
#endif
};


static __init blabbermouth_init(void){
	/* register the hooks */	
	
	if (register_security(&blabbermouth_ops))
		panic("blabbermouth: Unable to register blabbermouth with kernel.\n");
	else 
		printk("blabbermouth: registered with the kernel\n");

	return 0;
}

static void __exit blabbermouth_exit (void)
{	
	return;
}



module_init (blabbermouth_init);
module_exit (blabbermouth_exit);

//MODULE_DESCRIPTION("blabbermouth");
//MODULE_LICENSE("GPL");
#endif /* CONFIG_SECURITY_blabbermouth */

